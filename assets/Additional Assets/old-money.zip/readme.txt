Old Money is a handcrafted serif font. Free for personal and commercial use. If you dig it, tag @cutlip_ on instagram, we'd love to see how you put it to use!

https://www.behance.net/charliecutlip

https://cutlipcreative.com/


